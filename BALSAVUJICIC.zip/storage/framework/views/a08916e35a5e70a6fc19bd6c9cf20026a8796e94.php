<?php $__env->startSection('body'); ?>
    <section class="wpm_about_area">
        <div class="container">
            <div class="col-xs-8">
                <h1 class="text-center"><?php echo e($podaci['vesti'][$podaci['active']]['naslov']); ?></h1>
                <p class="text-center"><?php echo e($podaci['vesti'][$podaci['active']]['datum']); ?></p>
                <?php echo $podaci['vesti'][$podaci['active']]['full-txt']; ?>

            </div>
            <div class="col-xs-4">
                <h3><?php echo e(trans('tekstovi.vesti-sve')); ?></h3>
                <ul class="list-group wpm_list">
                    <?php foreach($podaci['vesti'] as $vest): ?>
                        <a href="/vest/<?php echo e($vest['slug']); ?>"><li class="list-group-item"><?php echo e($vest['naslov']); ?> <small class="float-right"><?php echo e($vest['datum']); ?></small></li></a>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>