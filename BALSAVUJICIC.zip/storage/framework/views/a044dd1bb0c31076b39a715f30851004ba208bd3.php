<?php $__env->startSection('body'); ?>
    <style>
        .activeimg,.miniimg{
            margin: 0 auto;width: auto;
        }
        .miniimg{width: 800px}
        .miniimg img{
            width: auto; float:left; margin: 0 5px 5px 0;
        }
    </style>
    <section class="wpm_about_area">
        <div class="container">
            <div class="col-xs-12">
                <h1 class="text-center"><?php echo e($podaci['naslov']); ?></h1>
            </div>
            <div class="col-xs-2">
                <a href="/<?php echo e(strtolower(trans('tekstovi.foto'))); ?>/1" title="<?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 1"><?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 1</a><br>
                <a href="/<?php echo e(strtolower(trans('tekstovi.foto'))); ?>/2" title="<?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 2"><?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 2</a><br>
                <a href="/<?php echo e(strtolower(trans('tekstovi.foto'))); ?>/3" title="<?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 3"><?php echo e(trans('tekstovi.foto')); ?> <?php echo e(trans('tekstovi.nav-galerija')); ?> 3</a><br>
                <a href="/<?php echo e(strtolower(trans('tekstovi.video'))); ?>" title="<?php echo e(trans('tekstovi.video')); ?>"><?php echo e(trans('tekstovi.video')); ?></a>
            </div>
            <div class="col-xs-10">
                <?php if($podaci['tip']=='foto'): ?>
                <div class="miniimg">
                    <?php for($i=1;$i<$podaci['broj']+1;$i++): ?>
                        <img src="/images/galerije/<?php echo e($podaci['id']); ?>/mini/<?php echo e($i); ?>.jpg" alt="" width="75" height="56" class="miniimg" data-id="<?php echo e($i); ?>" data-gid="<?php echo e($podaci['id']); ?>" onclick="prikaziFoto(this)" onmouseenter="prikaziFoto(this)">
                    <?php endfor; ?>
                </div>
                <img src="/images/galerije/<?php echo e($podaci['id']); ?>/full/1.jpg" alt="" width="800" height="600" class="activeimg">
                <?php else: ?>
                    <?php foreach($podaci['video'] as $video): ?>
                        <?php echo e($video['naslov']); ?><br>
                        <object width="600" height="450" data="<?php echo e($video['url']); ?>"></object>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('end-script'); ?>
    <script>
        function prikaziFoto(el){
            if($(el).data('id')!=$('.activeimg').data('id'))
            $('.activeimg').attr('src','/images/galerije/'+$(el).data('gid')+'/full/'+$(el).data('id')+'.jpg').data('id',$(el).data('id'));
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>