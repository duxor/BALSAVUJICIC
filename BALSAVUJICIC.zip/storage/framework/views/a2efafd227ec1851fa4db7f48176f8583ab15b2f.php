<?php $__env->startSection('body'); ?>
    <section class="wpm_about_area">
        <div class="container">
            <div class="col-sm-6">
                <?php echo $podaci['txt']; ?>

            </div>
            <div class="col-sm-6">
                <?php if($podaci['img']): ?>
                    <?php foreach($podaci['img'] as $img): ?>
                        <img src="<?php echo e($img); ?>" alt="Balša Vujičić - img">
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>