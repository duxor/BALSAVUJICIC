<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Balsa Vujicic - Teniserski trener</title>

    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/css/animation.css" />
    <link rel="stylesheet" type="text/css" href="/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="/style.css" />
    <link rel="stylesheet" type="text/css" href="/responsive.css" />

    <link rel="stylesheet" type="text/css" href="/css/style_common.css" />
    <link rel="stylesheet" type="text/css" href="/css/style10.css" />
    <link rel="stylesheet" type="text/css" href="/css/set2.css" />
    <link rel="stylesheet" type="text/css" href="/css/normalize.css" />
    <style type="text/css">
        <!--
        .style1 {color: #000000}
        -->
    </style>
</head>

<body>
<div id="home"></div>
<header class="wpm_header">
    <div class="container">
        <div class="row">
            <div class="col-sm-3"  data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}">
                <a  href="index.html">
                    <img src="images/logo/logo.png" alt="Balša Vujičić - Logo" width="291" height="61" class="wpm_logo wpm_mobile_center">
                </a>
            </div>

            <div class="col-sm-8">
                <nav class="navbar navbar-default wpm_navber">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mnav">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="collapse navbar-collapse" id="mnav">
                        <ul class="nav navbar-nav navbar-right wpm_menu">
                            <li><a href="#home">POCETNA</a></li>
                            <li><a href="#about">BALŠA</a></li>
                            <li><a href="#service">Service</a></li>
                            <li><a href="#portfolio">Portfolio</a> </li>
                            <li><a href="#blog">Blog</a></li>
                            <li><a href="#contact">Contact us</a> </li>
                        </ul>
                    </div>
                </nav>
            </div>

            <div class="col-sm-1 wpm_popup_area text-center">
                <a href="#" data-toggle="modal" data-target="#myModal"> <i class="fa fa-search-plus"></i> </a>
                <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close hvr-pulse-shrink" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">You can search here</h4>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                    </div>
                                    <button type="submit" class="btn btn-default hvr-pulse-shrink">SUBMIT</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default hvr-pulse-shrink" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<section class="wpm_slider_area">


    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">

            <div class="item active">
                <img src="images/slider/01.jpg" alt="nase nade">
                <div class="carousel-caption">
                    <h1>Tenisrke i teniseri</h1><br>

                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Get Started</button></a>
                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Learn More</button></a>

                </div>
            </div>

            <div class="item">
                <img src="images/slider/02.jpg" alt="...">
                <div class="carousel-caption">
                    <h1>Budući teniski šampioni</h1><br>

                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Get Started</button></a>
                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Learn More</button></a>
                </div>
            </div>

            <div class="item">
                <img src="images/slider/03.jpg" alt="...">

                <div class="carousel-caption">
                    <h1>Budući teniski šampioni</h1><br>

                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Get Started</button></a>
                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Learn More</button></a>
                </div>
            </div>

            <div class="item">

                <img src="images/slider/04.jpg" alt="...">

                <div class="carousel-caption">
                    <h1>Moja malenkost</h1><br>


                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Get Started</button></a>
                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Learn More</button></a>
                </div>
            </div>

            <div class="item">

                <img src="images/slider/05.jpg" alt="...">

                <div class="carousel-caption">
                    <h1>Lorem ipsum dolor sit amet</h1><br>


                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Get Started</button></a>
                    <a href="#"><button class="btn btn-default hvr-pulse-shrink" type="submit">Learn More</button></a>
                </div>
            </div>

        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

</section>



<section class="wpm_about_area" id="about">

    <div class="container">

        <div class="row">

            <div class="col-sm-12 text-center">

                <h2 data-uk-scrollspy="{cls:'uk-animation-fade',}">BALŠA</h2>

                <h5 class="sub_title">NeŠto o meni u kratkim crtama</h5>

                <div class="wpm_border"> <div class="wpm_inside_border"> </div>  </div>

            </div>

        </div>

        <div class="row">

            <div class="col-sm-6">


                <div class="clearfix"></div>

                <h3>BALŠA VUJIČIĆ </h3>

                <p>Zovem se Balša Vujičić, rođen sam u 02.06.1982. godine u Vršcu gde sam pohađao osnovnu i srednju školu, još sa pet godina uzeo sam reket u ruke i istog momenta tenis zavoleo. Zivim i radim u Beogradu.  </p>
                <p>Posedujem bogato igračko i trenersko iskustvo. Bio sam među prih deset juniora Jugoslavije. Osvajao sam brojne turnire, teniske kampove kao i klupske turnire. Od svoje 12 godine igrаo sam ekipnа prvenstvа zа TK Vršаc, počev od vojvođаnske lige, preko Druge sаvezne pа sve do Prve sаvezne lige, u Crnoj Gori igrаo sam Prvu sаveznu ligu zа TK SBS.</p>
                <p>Posedujem B licencu, itf level 2 (Aleš Filipčič), diplomu učiteljа tenisа (Rаdmilo Armenulić, Dejаn Simić) kao i sertifikаt o stečenoj C licenci teniskog trenerа TSS.</p>

                <ul class="list-group">
                    <li class="list-group-item"> <i class="fa fa-check-circle"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                    <li class="list-group-item"> <i class="fa fa-check-circle"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                    <li class="list-group-item"> <i class="fa fa-check-circle"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                    <li class="list-group-item"> <i class="fa fa-check-circle"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                    <li class="list-group-item"> <i class="fa fa-check-circle"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>



                </ul>

            </div>

            <div class="col-sm-6 wpm_ing_col">

                <img src="images/pozadina.jpg" width="1900" height="1330" data-uk-scrollspy="{cls:'uk-animation-slide-right', }">

                <p>U svojoj karijeri imam preko 10 godinа trenerskog stаžа, i to u radu sa svim uzrastima i kvalitetima. Posedujm sopstvenu školu tenisа sа preko 40 klinаcа, od kojih su mnogi učenici kаsnije postаli neki od nаjboljih juniorа u svojim konkurencijаmа (Đorđe Jocić, Pepe Mаrjаnović, Stefаn Blаnušа, Petаr Bаrčot). Trener sam mnogim nаšim jаvnim ličnostimа (Kiki Lesendrić, Sаšа Popović, Aco Pejović, Dženаn Lončаrević, Dаdo Glišić...). Spаring pаrtner sam Drаgаni Zаrić (WTA 157, dubl 82). U 2004. godini bio sam glаvni trener u SBS (Crnа Gorа), a od 2006. sаm trener u TK Đukić.</p>

            </div>

        </div>

    </div>

</section>



<section class="wpm_order_area">

    <div class="wpm_opacity">

        <div class="container">

            <div class="row">

                <div class="col-sm-12 wpm_mobile_center">

                    <h3>Lorem Ipsum is simply dummy</h3>

                    <button class="btn btn-default" type="submit">JOIN US!</button>

                    <P>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</P>

                </div>

            </div>

        </div>

    </div>

</section>


<section class="wpm_service_area" id="service">

    <div class="wpm_opacity">

        <div class="container">

            <div class="row">

                <div class="col-sm-12">

                    <h2>Our Services</h2>

                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

                </div>

            </div>

            <div class="row">

                <div class="col-sm-4">

                    <div class="wpm_service_box bg1">

                        <i class="fa fa-code" data-uk-scrollspy="{cls:'uk-animation-scale-up', repeat: true}"></i>

                        <h1>fully Responsive</h1>

                        <div class="wpm_border"></div>

                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type.</p>

                    </div>

                </div>

                <div class="col-sm-4">

                    <div class="wpm_service_box bg2">

                        <i class="fa fa-code" data-uk-scrollspy="{cls:'uk-animation-scale-up', repeat: true}"></i>

                        <h1>fully Responsive</h1>

                        <div class="wpm_border"></div>

                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type.</p>

                    </div>

                </div>

                <div class="col-sm-4">

                    <div class="wpm_service_box bg3">

                        <i class="fa fa-code" data-uk-scrollspy="{cls:'uk-animation-scale-up', repeat: true}"></i>

                        <h1>fully Responsive</h1>

                        <div class="wpm_border"></div>

                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type.</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>




<section class="wpm_portfolio_area" id="portfolio">

    <div class="container">

        <div class="row">

            <div class="col-sm-12">

                <h2>Portfolio</h2>

            </div>

        </div>


        <div class="row">
            <div class="col-sm-12">

                <div class="wpm_mixitup_menu">
                    <button class="filter" data-filter="all">All</button>
                    <button class="filter" data-filter=".webdesign">Web design</button>
                    <button class="filter" data-filter=".php">PHP</button>
                    <button class="filter" data-filter=".jquery">Jquery</button>
                </div>

                <div id="Container">
                    <div class="mix all" data-my-order="1">
                        <img src="images/work/01.jpg">
                    </div>


                    <div class="mix webdesign" data-my-order="2">
                        <img src="images/work/02.jpg">
                    </div>
                    <div class="mix webdesign" data-my-order="2">
                        <img src="images/work/03.jpg">
                    </div>
                    <div class="mix webdesign" data-my-order="2">
                        <img src="images/work/04.jpg">
                    </div>



                    <div class="mix php" data-my-order="3">
                        <img src="images/work/05.jpg">
                    </div>
                    <div class="mix php" data-my-order="3">
                        <img src="images/work/06.jpg">
                    </div>



                    <div class="mix jquery" data-my-order="4">
                        <img src="images/work/07.jpg">
                    </div>
                    <div class="mix jquery" data-my-order="4">
                        <img src="images/work/08.jpg">
                    </div>
                    <div class="mix jquery" data-my-order="4">
                        <img src="images/work/09.jpg">
                    </div>


                </div>

            </div>
        </div>


        <div class="row">
            <div class="col-sm-3">

                <div id="Container">
                    <div class="mix all" data-my-order="1">
                        <img src="images/work/01.jpg">
                    </div>
                </div>

            </div>

            <div class="col-sm-3">

                <div id="Container">
                    <div class="mix all" data-my-order="1">
                        <img src="images/work/02.jpg">
                    </div>
                </div>

            </div>

            <div class="col-sm-3">

                <div id="Container">
                    <div class="mix all" data-my-order="1">
                        <img src="images/work/03.jpg">
                    </div>
                </div>

            </div>

            <div class="col-sm-3">
                <div id="Container">
                    <div class="mix all" data-my-order="1">
                        <img src="images/work/04.jpg">
                    </div>
                </div>
            </div>
        </div>

    </div>

</section>



<section class="wpm_blog_area" id="blog">

    <div class="container">

        <div class="row">

            <h2 data-uk-scrollspy="{cls:'uk-animation-fade', repeat: true}">Our Blog</h2>

            <h5 class="sub_title">Lorem Ipsum is simply dummy text of the printing and typesetting industry</h5>

            <div class="wpm_border"> <div class="wpm_inside_border"> </div>  </div>

            <div class="col-sm-8" data-uk-scrollspy="{cls:'uk-animation-slide-left',}">

                <img src="images/slider/01.jpg" alt="">

                <div class="blog_link_area">

                    <h3><a href="#">Many web sites still in their infancy</a></h3>

                    <a href="#" class="date">27 October 2015</a>

                    <span> In:<a href="#">Web tutorials</a></span>

                    <span> Note:<a href="#">22 comment</a></span>

                </div>

                <p class="para">Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years <a href="#">read more...</a></p>


            </div>

            <div class="col-sm-4" data-uk-scrollspy="{cls:'uk-animation-slide-right',}">

                <h3>All Events</h3>

                <ul class="list-group wpm_list">

                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>
                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>

                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>
                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>

                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>
                    <a href="#"><li class="list-group-item">Lorem Ipsum is that it has a more </li></a>
                    <li class="list-group-item">Lorem Ipsum is that it has a more</li>

                </ul>

            </div>

        </div>

    </div>

</section>



<section class="wpm_contact_area" id="contact">

    <div class="container">

        <div class="row">

            <div class="col-sm-6" data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}">

                <div class="wpm_address">

                    <h3>GDE RADIM</h3>

                    <p>TK Đukić</p>
                    <p>Partizanske avijacije 1</p>
                    <p>Bežanijska kosa</p>
                    <p>11000 Beogra , Srbija</p>
                    <p>Telefon: +381 63 839 86 65</p>

                    <p>Email: <a href="mailto:contact@balsavujicic.com" class="style1">contact@balsavujicic.com</a></p>

                </div>

                <div class="embed-responsive embed-responsive-16by9 wpm_maph ">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2332.394079310231!2d20.387583650521634!3d44.82408748384491!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a658f65979265%3A0xd710f74cf7e0d8ad!2sPartizanske+avijacije+1%2C+Beograd!5e1!3m2!1sen!2srs!4v1470350302674" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

                </div>

            </div>

            <div class="col-sm-6" data-uk-scrollspy="{cls:'uk-animation-slide-right', repeat: true}">

                <h3>KONTAKT FORMULAR</h3>

                    <span class="input input--nao">
                        <input class="input__field input__field--nao" type="text" id="input-1" />
                        <label class="input__label input__label--nao" for="input-1">
                            <span class="input__label-content input__label-content--nao">Ime</span>
                        </label>
                        <svg class="graphic graphic--nao" width="300%" height="100%" viewBox="0 0 1200 60" preserveAspectRatio="none">
                            <path d="M0,56.5c0,0,298.666,0,399.333,0C448.336,56.5,513.994,46,597,46c77.327,0,135,10.5,200.999,10.5c95.996,0,402.001,0,402.001,0"/>
                        </svg>
				    </span>


                    <span class="input input--nao">
                        <input class="input__field input__field--nao" type="text" id="input-1" />
                        <label class="input__label input__label--nao" for="input-1">
                            <span class="input__label-content input__label-content--nao">Email</span>
                        </label>
                        <svg class="graphic graphic--nao" width="300%" height="100%" viewBox="0 0 1200 60" preserveAspectRatio="none">
                            <path d="M0,56.5c0,0,298.666,0,399.333,0C448.336,56.5,513.994,46,597,46c77.327,0,135,10.5,200.999,10.5c95.996,0,402.001,0,402.001,0"/>
                        </svg>
				    </span>

                    <span class="input input--nao">
                        <input class="input__field input__field--nao" type="text" id="input-1" />
                        <label class="input__label input__label--nao" for="input-1">
                            <span class="input__label-content input__label-content--nao">Naslov Poruke</span>
                        </label>
                        <svg class="graphic graphic--nao" width="300%" height="100%" viewBox="0 0 1200 60" preserveAspectRatio="none">
                            <path d="M0,56.5c0,0,298.666,0,399.333,0C448.336,56.5,513.994,46,597,46c77.327,0,135,10.5,200.999,10.5c95.996,0,402.001,0,402.001,0"/>
                        </svg>
				    </span>

                <form>

                    <textarea class="massage_area wpm_textarea" cols="40" rows="8" placeholder="Massage"> </textarea>

                    <input class="wpm_send_btn" type="submit" value="POSALJI PORUKU">

                </form>



            </div>

        </div>

    </div>

</section>



<footer>

    <div class="container">

        <div class="row">

            <div class="col-sm-2">

                <h4>KONTAKT</h4>

                <p>+381 63 839 86 65</p>

                <a href="mailto:contact@balsavujicic.com">contact@balsavujicic.com</a><a href="#"></a>        </div>


            <div class="col-sm-2">

                <ul>

                    <li><a href="index.html">POCETNA</a></li>
                    <li><a href="about.html">BALŠA</a></li>
                    <li><a href="service.html">SERVICES</a></li>
                    <li><a href="portfolio.html">GALERIJA</a></li>
                    <li><a href="blog.html">BLOG</a></li>

                </ul>

            </div>


            <div class="col-sm-5">

                <h4>SUBSCRIBE TO OUR NEWSLETTER</h4>

                <form>

                    <div class="input-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter your email address">
                        <div class="input-group-addon"><button type="submit" class="btn btn-default">Submit</button></div>
                    </div>

                </form>

                <div class="social_icon">

                    <a href="#"><i class="fa fa-twitter-square"></i></a>
                    <a href="#"><i class="fa fa-facebook-square"></i></a>
                    <a href="#"><i class="fa fa-google-plus-square"></i></a>
                    <a href="#"><i class="fa fa-skype"></i></a>
                    <a href="#"><i class="fa fa-dribbble"></i></a>


                    <div class="clearfix"></div>
                </div>

            </div>


            <div class="col-sm-3">

                <div class="wpm_img_grup">

                    <img src="images/work/01.jpg">
                    <img src="images/work/02.jpg">
                    <img src="images/work/03.jpg">
                    <img src="images/work/04.jpg">
                    <img src="images/work/05.jpg">
                    <img src="images/work/06.jpg">
                    <img src="images/work/07.jpg">
                    <img src="images/work/08.jpg">
                    <img src="images/work/09.jpg">
                    <img src="images/work/03.jpg">

                </div>

            </div>

        </div>

    </div>

</footer>


    <section class="wpm_frooter_ending">
        <div class="container">
            <div class="col-sm-12 text-center wpm_mobile_center">
                <p>Copyright &copy; <?php echo e(date('Y')); ?> balsavujicic.com</p>
                <div class="copytext">
                    Design By <a href="http://dusanperisic.com" target="_blank" class="copylink">DevTeam</a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

    </section>


    <script src="js/jquery.min.js"></script>
    <script src="js/Main-script.min.js"></script>
</body>
</html>