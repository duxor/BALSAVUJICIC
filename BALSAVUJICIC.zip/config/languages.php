<?php

return [
    'rs' => 'Srpski',
    'en' => 'English'
];